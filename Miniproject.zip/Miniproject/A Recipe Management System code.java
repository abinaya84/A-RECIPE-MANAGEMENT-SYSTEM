import java.util.ArrayList;
import java.util.Scanner;

class Recipe {
    String name;
    String instructions;

    public Recipe(String name, String instructions) {
        this.name = name;
        this.instructions = instructions;
    }

    public void displayRecipe() {
        System.out.println("Recipe: " + name);
        System.out.println("Instructions: " + instructions);
    }
}

class RecipeCategory {
    String categoryName;
    ArrayList<Recipe> recipes;

    public RecipeCategory(String categoryName) {
        this.categoryName = categoryName;
        this.recipes = new ArrayList<>();
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    public void displayRecipes() {
        System.out.println("\nRecipes in " + categoryName + " category:");
        for (int i = 0; i < recipes.size(); i++) {
            System.out.println((i + 1) + ". " + recipes.get(i).name);
        }
    }

    public Recipe getRecipe(int index) {
        return recipes.get(index);
    }
}

public class RecipeManagementSystem {
    private static ArrayList<RecipeCategory> categories;

    public static void main(String[] args) {
        categories = new ArrayList<>();
        initializeCategories();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    displayCategories();
                    int categoryChoice = scanner.nextInt();
                    scanner.nextLine(); // consume the newline character
                    if (categoryChoice > 0 && categoryChoice <= categories.size()) {
                        RecipeCategory category = categories.get(categoryChoice - 1);
                        category.displayRecipes();
                        System.out.print("Select a recipe number: ");
                        int recipeChoice = scanner.nextInt();
                        scanner.nextLine(); // consume the newline character
                        if (recipeChoice > 0 && recipeChoice <= category.recipes.size()) {
                            category.getRecipe(recipeChoice - 1).displayRecipe();
                        } else {
                            System.out.println("Invalid recipe number.");
                        }
                    } else {
                        System.out.println("Invalid category number.");
                    }
                    break;
                case 2:
                    System.out.println("Exiting the system...");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public static void displayMenu() {
        System.out.println("\nWelcome to the Recipe Management System");
        System.out.println("1. View Recipes");
        System.out.println("2. Exit");
        System.out.print("Enter your choice: ");
    }

    public static void displayCategories() {
        System.out.println("\nSelect a category:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i).categoryName);
        }
        System.out.print("Enter category number: ");
    }

    public static void initializeCategories() {
        // Initialize Categories and Recipes with detailed instructions
        RecipeCategory veg = new RecipeCategory("Veg");
        veg.addRecipe(new Recipe("Vegetable Curry", 
                "1. Heat oil in a pan. " +
                "2. Add chopped onions and sauté until golden brown. " +
                "3. Add chopped tomatoes and cook until soft. " +
                "4. Add vegetables of choice (carrot, potato, beans, etc.) and cook for 5-7 minutes. " +
                "5. Add spices (turmeric, cumin, coriander, etc.), and cook for another 5 minutes. " +
                "6. Add water, salt, and simmer for 10-15 minutes until vegetables are tender. " +
                "7. Serve hot with rice or bread."));

        veg.addRecipe(new Recipe("Paneer Tikka", 
                "1. Mix paneer, yogurt, red chili powder, garam masala, lemon juice, ginger-garlic paste, and salt. " +
                "2. Marinate for 30 minutes. " +
                "3. Thread the paneer cubes onto skewers. " +
                "4. Grill or bake at 200°C for 10-12 minutes. " +
                "5. Serve with chutney and salad."));

        // Additional recipes...

        RecipeCategory nonVeg = new RecipeCategory("Non-Veg");
        nonVeg.addRecipe(new Recipe("Chicken Curry", 
                "1. Heat oil and sauté onions until golden. " +
                "2. Add ginger-garlic paste and sauté. " +
                "3. Add chopped tomatoes, cook until soft. " +
                "4. Add chicken pieces, cook for 10 minutes. " +
                "5. Add spices (turmeric, red chili, garam masala, etc.), and cook for another 10 minutes. " +
                "6. Add water and simmer until chicken is cooked. " +
                "7. Serve hot with rice or naan."));

        // Additional non-veg recipes...

        RecipeCategory sweets = new RecipeCategory("Sweets");
        sweets.addRecipe(new Recipe("Gulab Jamun", 
                "1. Make a dough with milk powder, flour, and baking soda. " +
                "2. Roll dough into small balls and fry in ghee. " +
                "3. Prepare sugar syrup with water, sugar, and cardamom. " +
                "4. Dip fried gulab jamuns in the syrup for 2-3 hours."));

        // Additional sweet recipes...

        categories.add(veg);
        categories.add(nonVeg);
        categories.add(sweets);
    }
}
